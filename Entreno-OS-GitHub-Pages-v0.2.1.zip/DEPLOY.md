# Despliegue en GitHub Pages

El procedimiento único de publicación de Entreno OS es GitHub Pages con GitHub Actions.

Lee [PUBLICAR.md](./PUBLICAR.md) para activar GitHub Pages, comprobar la URL pública y añadir la web a la pantalla de inicio del iPhone.

Comandos de verificación local:

```bash
npm test
npm run build
```

El flujo automatizado `.github/workflows/pages.yml` ejecuta ambos y publica exclusivamente el contenido de `dist/` en cada push a `main`.

**No hay chatbot, servidor de aplicación, cuentas obligatorias ni servicios externos de IA.** Los registros se guardan en el navegador. Nunca subas copias JSON del historial a un repositorio público.
