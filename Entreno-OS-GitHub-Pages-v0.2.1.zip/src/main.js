import { db } from './db.js';
import { EXERCISES, GEAR, DAYS, ACTIVITY_TYPES } from './data.js';
import { icon } from './icons.js';
import { localDate, parseLocalDate, addDays, weekStart, dateLabel, fullDateLabel, uuid, findExercise, planForWeek, newSession, defaultSet, countDone, totalVolume, cardioTotals, durationMinutes, statsFor, historyByWeek, recordsFor, clampNonNegative } from './domain.js';

const el = document.getElementById('app');
const state = {profile:null,plans:[],sessions:[],page:'home',week:weekStart(),modal:null,selectedGoal:'Rendimiento híbrido',selectedDays:6,selectedGear:['corporal','mancuernas'],toast:'',busy:false};
const escapeHtml = value => String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const fmt = n => new Intl.NumberFormat('es-ES',{maximumFractionDigits:1}).format(n||0);
const cap = s=>s.charAt(0).toUpperCase()+s.slice(1);
const getPlan = date => state.plans.find(p=>p.date===date);
const getSession = id => state.sessions.find(s=>s.id===id);
const byPlan = id => state.sessions.filter(s=>s.planId===id).sort((a,b)=>b.startedAt.localeCompare(a.startedAt));
const currentSession = () => state.sessions.filter(s=>s.status==='active').sort((a,b)=>b.startedAt.localeCompare(a.startedAt))[0];
const completedForPlan = id => byPlan(id).find(s=>s.status==='completed');
const getActiveForPlan = id => byPlan(id).find(s=>s.status==='active');
const pill = (text,kind='neutral')=>`<span class="pill pill-${kind}">${escapeHtml(text)}</span>`;
const minutes = (n)=>`${Math.round(n)} min`;
const firstName = ()=>escapeHtml((state.profile?.name||'Atleta').trim().split(/\s+/)[0]);
const button = (action,label,extra='',attrs='')=>`<button class="btn ${extra}" data-action="${action}" ${attrs}>${label}</button>`;
const availableExercises=()=>EXERCISES.filter(ex=>ex.gear==='corporal'||(state.profile?.gear||[]).includes(ex.gear));

async function reload(){const [profile,plans,sessions]=await Promise.all([db.getProfile(),db.all('plans'),db.all('sessions')]);Object.assign(state,{profile,plans,sessions});}
function notice(message){let node=document.getElementById('app-toast');if(!node){node=document.createElement('div');node.id='app-toast';node.className='toast';node.setAttribute('role','status');document.body.append(node)}node.textContent=message;node.classList.add('toast-visible');clearTimeout(notice.timer);notice.timer=setTimeout(()=>node.classList.remove('toast-visible'),3400)}
function appShell(content){return `<div class="app-shell">
<aside class="desktop-side"><a class="brand" href="#home" data-action="home"><img src="./assets/logo.svg" width="42" height="42" alt=""/><div><strong>ENTRENO <span>OS</span></strong><small>PERFORMANCE SYSTEM</small></div></a>
<div class="side-group-label">WORKSPACE</div>${navItem('home','Inicio','home')}${navItem('plan','Plan semanal','calendar')}${navItem('train','Entrenamiento','dumbbell')}${navItem('progress','Progreso','chart')}
<div class="sidebar-space"></div><div class="side-group-label">CUENTA</div>${navItem('settings','Ajustes','settings')}<div class="side-note"><span class="online-dot"></span> Tus datos permanecen en este dispositivo<div class="side-note-sub">Entreno OS · Versión 0.1</div></div></aside>
<div class="app-body"><header class="topbar"><div class="mobile-brand"><img src="./assets/logo.svg" width="32" height="32" alt=""/><span>ENTRENO <b>OS</b></span></div><span class="topbar-context">${cap(state.page==='train'?'Entrenamiento':state.page==='progress'?'Progreso':state.page==='plan'?'Plan semanal':state.page==='settings'?'Ajustes':'Panel principal')}</span><div class="top-actions"><span class="system-status"><span class="online-dot" id="connectivity-dot"></span><span id="connectivity-label">${navigator.onLine?'Local · listo':'Sin conexión'}</span></span><button class="profile-chip" data-action="settings" aria-label="Abrir ajustes">${firstName().charAt(0).toUpperCase()}</button></div></header>
<main class="content" id="main-content">${content}</main></div>
<nav class="bottom-nav" aria-label="Navegación principal">${bottomItem('home','Inicio','home')}${bottomItem('plan','Plan','calendar')}${bottomItem('train','Entrenar','dumbbell')}${bottomItem('progress','Progreso','chart')}${bottomItem('settings','Más','more')}</nav></div>`;}
function navItem(page,label,glyph){return `<button class="side-link ${state.page===page?'selected':''}" data-action="${page}">${icon(glyph,20)}<span>${label}</span>${state.page===page?'<span class="side-selected-mark"></span>':''}</button>`}
function bottomItem(page,label,glyph){return `<button class="bottom-tab ${state.page===page?'selected':''}" data-action="${page}" aria-label="${label}" ${state.page===page?'aria-current="page"':''}>${icon(glyph,21)}<span>${label}</span></button>`}
function pageHead(eyebrow,title,desc,action=''){return `<div class="page-head"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`}
function sectionHead(title,sub='',action=''){return `<div class="section-head"><div><h2>${title}</h2>${sub?`<p>${sub}</p>`:''}</div>${action}</div>`}
function smallMetric(glyph,label,value,note=''){return `<div class="metric-card"><span class="metric-icon">${icon(glyph,19)}</span><div class="metric-label">${label}</div><strong>${value}</strong>${note?`<span class="metric-note">${note}</span>`:''}</div>`}

function onboarding(){return `<div class="onboarding"><div class="onboard-art"><div class="onboard-art-inner"><img class="onboard-logo" src="./assets/logo.svg" alt=""/><span class="eyebrow">PERFORMANCE, REIMAGINED</span><h1>Tu potencial.<br/><em>Tu sistema.</em></h1><p>Planifica con intención. Entrena a tu ritmo. Sigue tu evolución.</p><div class="onboard-art-badge">${icon('shield',16)} Datos privados y locales</div></div></div>
<div class="onboard-form"><div class="form-topline"><span class="form-step">CONFIGURACIÓN INICIAL</span><span class="form-step-muted">01 / 01</span></div><h2>Diseñado para ti.</h2><p class="muted">Configura tu punto de partida. Podrás editarlo cuando quieras.</p>
<form data-form="onboarding" class="form-stack">
<label class="field-label" for="name">¿Cómo quieres que te llamemos? <span>Opcional</span></label><input id="name" class="text-input" name="name" maxlength="48" placeholder="Tu nombre" autocomplete="given-name" />
<div class="field-label">Objetivo prioritario</div><div class="choice-grid goal-grid">${['Rendimiento híbrido','Fuerza','Resistencia','Movilidad'].map(goal=>`<label class="choice-card"><input type="radio" name="goal" value="${goal}" ${goal==='Rendimiento híbrido'?'checked':''}/><span>${icon(goal==='Fuerza'?'dumbbell':goal==='Resistencia'?'activity':goal==='Movilidad'?'wind':'flash',19)}${goal}</span></label>`).join('')}</div>
<div class="field-label">Material disponible</div><div class="gear-choices">${GEAR.map(g=>`<label class="check-chip"><input type="checkbox" name="gear" value="${g.id}" ${['corporal','mancuernas'].includes(g.id)?'checked':''}/><span>${escapeHtml(g.name)}</span></label>`).join('')}</div>
<div class="field-label">Días planificados por semana</div><div class="number-choices">${[3,4,5,6].map(n=>`<label class="number-choice"><input type="radio" name="days" value="${n}" ${n===6?'checked':''}/><span>${n}</span></label>`).join('')}</div>
<div class="soft-notice">${icon('info',17)} El plan incluirá intensidades variadas y descanso. Siempre podrás cambiarlo.</div>
<button class="btn btn-primary btn-block btn-large" type="submit">Crear mi espacio ${icon('arrow',18)}</button></form></div></div>`}

function dashboard(){
 const today=localDate(),todayPlan=getPlan(today),active=currentSession(),thisWeek=weekStart(today),s=statsFor(state.sessions,state.plans,thisWeek);
 const target=active?getPlan(active.date):todayPlan;
 const isRest=target?.isRest&&!active;
 const title=active?'Tienes una sesión en curso':target&&!isRest?target.title:isRest?'Hoy toca recuperar':'Tu siguiente sesión empieza aquí';
 const category=active?'SESIÓN EN CURSO':isRest?'RECUPERACIÓN ACTIVA':target?'PLAN DE HOY':'SIN SESIÓN PROGRAMADA';
 const description=active?'Continúa donde lo dejaste. Tus registros están guardados.':isRest?'El descanso también es parte del progreso.':target?`${target.minutes} minutos previstos · ${target.exerciseIds.length} actividades`:'Consulta tu plan semanal o prepara una nueva sesión.';
 const heroAction=active?button('resume',`${icon('play',18)} Reanudar sesión`,'btn-primary btn-large'):target&&!isRest?completedForPlan(target.id)?button('progress',`${icon('check',18)} Sesión completada`,'btn-ghost btn-large'):button('start',`${icon('play',18)} Empezar entrenamiento`,'btn-primary btn-large',`data-plan="${target.id}"`):button('plan',`${icon('calendar',18)} Abrir planificación`,'btn-primary btn-large');
 const upcoming=Array.from({length:5},(_,i)=>getPlan(addDays(today,i))).filter(Boolean);
 return `${pageHead('TU CENTRO DE RENDIMIENTO',`Hola, ${firstName()} <span class="wave">✦</span>`,`Hoy es ${cap(new Intl.DateTimeFormat('es-ES',{weekday:'long',day:'numeric',month:'long'}).format(new Date()))}`)}
<section class="hero"><div class="hero-art"></div><div class="hero-content"><div class="hero-top">${icon('spark',15)} ${category}</div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(description)}</p><div class="hero-action">${heroAction}${target&&!isRest?`<span class="hero-secondary">${icon('clock',16)} ${target.minutes} min estimados</span>`:''}</div></div><div class="hero-mark">EOS / 01</div></section>
<div class="section-title-spacer">${sectionHead('Tu semana','Los datos se calculan desde tus sesiones registradas.',`<span class="week-tag">${dateLabel(thisWeek)} — ${dateLabel(addDays(thisWeek,6))}</span>`)}</div>
<div class="metric-grid">${smallMetric('check','Sesiones completadas',`${s.completed}<span class="metric-out-of"> / ${s.planned}</span>`,'Esta semana')}${smallMetric('clock','Tiempo entrenado',`${fmt(s.minutes)}<span class="metric-unit"> min</span>`,'Sesiones finalizadas')}${smallMetric('activity','Carga registrada',`${fmt(s.volume)}<span class="metric-unit"> kg</span>`,'Repeticiones × carga')}${smallMetric('chart','Constancia',`${s.consistency}<span class="metric-unit">%</span>`,'Sesiones planificadas')}</div>
<div class="home-grid"><section class="panel"><div class="panel-header">${sectionHead('Próximos días','Tu agenda deportiva',`<button class="link-action" data-action="plan">Ver calendario ${icon('arrow',15)}</button>`)}</div><div class="upcoming-list">${upcoming.length?upcoming.map(p=>{const done=completedForPlan(p.id),ongoing=getActiveForPlan(p.id);return `<div class="upcoming-item"><div class="upcoming-date"><b>${parseLocalDate(p.date).getDate()}</b><small>${cap(new Intl.DateTimeFormat('es-ES',{weekday:'short'}).format(parseLocalDate(p.date)).replace('.',''))}</small></div><div class="upcoming-info"><strong>${escapeHtml(p.title)}</strong><span>${p.isRest?'Recuperación':`${p.type} · ${p.minutes} min`}</span></div>${done?`<span class="status-dot status-done">${icon('check',15)}</span>`:ongoing?pill('En curso','violet'):p.isRest?`<span class="status-dot status-rest">${icon('wind',16)}</span>`:`<span class="status-dot">${icon('chevron',18)}</span>`}</div>`}).join(''):'<div class="empty-sm">Todavía no hay un plan para estos días.</div>'}</div></section>
<section class="panel progress-preview"><div class="panel-header">${sectionHead('Evolución','Sesiones completadas por semana',`<button class="link-action" data-action="progress">Analizar ${icon('arrow',15)}</button>`)}</div>${barChart(historyByWeek(state.sessions,thisWeek,6),'count')}<div class="insight-line">${icon('info',17)} Los gráficos muestran tus registros reales, sin datos de ejemplo.</div></section></div>
<div class="subtle-foot">${icon('shield',14)} Tus entrenamientos se almacenan en este dispositivo. Exporta copias desde Ajustes.</div>`;
}
function barChart(points,key='count'){
 const max=Math.max(1,...points.map(p=>p[key]));
 return `<div class="bar-chart" role="img" aria-label="Historial de ${key==='count'?'sesiones':'volumen'} por semana: ${points.map(p=>p.label+': '+p[key]).join(', ')}">${points.map((p,i)=>`<div class="chart-column"><div class="chart-value">${p[key]||''}</div><div class="chart-track"><div class="chart-bar ${i===points.length-1?'latest':''}" style="height:${Math.max(p[key]>0?10:2,(p[key]/max)*100)}%"></div></div><div class="chart-label">${p.label}</div></div>`).join('')}</div>`;
}
function planPage(){
 const monday=state.week,end=addDays(monday,6),weekly=Array.from({length:7},(_,i)=>getPlan(addDays(monday,i))),complete=weekly.filter(p=>p&&!p.isRest&&completedForPlan(p.id)).length,scheduled=weekly.filter(p=>p&&!p.isRest).length;
 return `${pageHead('PROGRAMACIÓN', 'Plan semanal', 'Una estructura flexible, diseñada para adaptarse a tus días.',`<button class="btn btn-outline" data-action="create-week">${icon('plus',17)} ${weekly.some(Boolean)?'Regenerar semana':'Crear semana'}</button>`)}
<div class="plan-toolbar"><div class="plan-dates"><button class="round-button" data-action="prev-week" aria-label="Semana anterior">${icon('back',20)}</button><div><strong>${dateLabel(monday)} — ${dateLabel(end)}</strong><span>${parseLocalDate(monday).getFullYear()}</span></div><button class="round-button" data-action="next-week" aria-label="Semana siguiente">${icon('chevron',20)}</button></div><div class="plan-progress">${icon('check',16)} ${complete} de ${scheduled} completadas</div></div>
<div class="week-board">${weekly.map((p,i)=>{const date=addDays(monday,i),today=date===localDate(),session=p&&completedForPlan(p.id),active=p&&getActiveForPlan(p.id);return `<article class="day-card ${today?'today':''} ${p?.isRest?'rest-day':''}"><div class="day-card-head"><div><span class="day-name">${DAYS[i]}</span><strong>${parseLocalDate(date).getDate()}</strong></div>${today?pill('HOY','violet'):session?pill('Hecho','green'):active?pill('En curso','violet'):p?.isRest?pill('Descanso','neutral'):''}</div><div class="day-card-body"><span class="activity-mark ${p?.type==='Fuerza'?'strength':p?.type==='Resistencia'?'cardio':p?.type==='Movilidad'?'mobility':''}">${icon(p?.type==='Fuerza'?'dumbbell':p?.type==='Resistencia'?'activity':p?.type==='Movilidad'?'wind':'calendar',18)}</span><h3>${escapeHtml(p?.title||'Sin planificar')}</h3><p>${!p?'Añade tu sesión':p.isRest?'Recupera y adapta tu semana':`${p.minutes} min · ${p.exerciseIds.length} actividades`}</p></div><div class="day-card-actions">${p&&!p.isRest&&!session?button(active?'resume':'start',`${icon(active?'play':'play',16)} ${active?'Continuar':'Empezar'}`,'btn-mini btn-soft',`data-plan="${p.id}"`):p&&session?'<span class="completed-label">'+icon('check',16)+' Finalizada</span>':`<span class="muted-label">${p?.isRest?'Día flexible':'Sin actividad'}</span>`}<button class="icon-button" data-action="edit-plan" data-date="${date}" aria-label="Editar día ${DAYS[i]}">${icon('edit',17)}</button></div></article>`}).join('')}</div>
<div class="tip-panel">${icon('info',19)} <div><strong>Un plan es una guía, no una obligación.</strong><p>Ajusta días e intensidad según tu recuperación. La planificación no sustituye el asesoramiento de un profesional deportivo cuando sea necesario.</p></div></div>`;
}

function trainingPage(){const s=currentSession();if(s)return activeWorkout(s);const today=localDate(),todayPlan=getPlan(today);const candidates=state.plans.filter(p=>!p.isRest && !completedForPlan(p.id)).sort((a,b)=>Math.abs(parseLocalDate(a.date)-parseLocalDate(today))-Math.abs(parseLocalDate(b.date)-parseLocalDate(today))).slice(0,8);
 return `${pageHead('ESPACIO DE ENTRENAMIENTO','Entrenar','Aquí comienza el trabajo real: un ejercicio y una serie cada vez.')}${todayPlan&&!todayPlan.isRest?`<div class="featured-plan">${pill('SESIÓN DE HOY','violet')}<h2>${escapeHtml(todayPlan.title)}</h2><p>${todayPlan.exerciseIds.length} actividades · ${todayPlan.minutes} min previstos</p>${button('start',`${icon('play',18)} Empezar sesión`,'btn-primary',`data-plan="${todayPlan.id}"`)}</div>`:''}<div class="section-title-spacer">${sectionHead('Sesiones disponibles','Elige una sesión de tu plan para comenzar.')}</div><div class="session-options">${candidates.length?candidates.map(p=>`<button class="session-option" data-action="start" data-plan="${p.id}"><span class="activity-mark ${p.type==='Fuerza'?'strength':p.type==='Resistencia'?'cardio':'mobility'}">${icon(p.type==='Fuerza'?'dumbbell':p.type==='Resistencia'?'activity':'wind',20)}</span><span><strong>${escapeHtml(p.title)}</strong><small>${dateLabel(p.date)} · ${p.minutes} min · ${p.exerciseIds.length} actividades</small></span>${icon('arrow',19)}</button>`).join(''):'<div class="empty-state">No hay sesiones pendientes. Puedes organizar nuevas sesiones desde el plan semanal.</div>'}</div>`;
}
function activeWorkout(s){
 const planned=getPlan(s.date),sets=(s.entries||[]).reduce((n,e)=>n+(e.sets||[]).length,0),done=countDone(s),pct=sets?Math.round(done/sets*100):0,seconds=s.restUntil?Math.max(0,Math.ceil((s.restUntil-Date.now())/1000)):0;
 return `<div class="workout-header"><button class="back-button" data-action="home">${icon('back',19)} <span>Volver al inicio</span></button><span class="workout-saved">${icon('shield',15)} Guardado automático</span></div><div class="workout-title-row"><div><div class="eyebrow">SESIÓN ACTIVA · ${dateLabel(s.date)}</div><h1>${escapeHtml(s.title)}</h1><p>${s.entries.length} actividades · ${done} de ${sets} registros completados</p></div><div class="progress-circle" style="--pct:${pct}"><span>${pct}%</span></div></div>
<div class="workout-progress-track"><div style="width:${pct}%"></div></div>
<div class="workout-layout"><div class="exercise-stack">${s.entries.map((e,i)=>exerciseCard(e,i)).join('')}${s.entries.length===0?'<div class="empty-state">Añade ejercicios a la sesión desde el planificador.</div>':''}<div class="finish-row">${button('finish',`${icon('check',19)} Finalizar sesión`,'btn-primary btn-large')}${button('home','Continuar más tarde','btn-outline btn-large')}</div></div><aside class="workout-rail"><div class="timer-panel"><div class="eyebrow">TEMPORIZADOR DE DESCANSO</div><div class="timer-circle"><span data-timer-value>${timeDisplay(seconds)}</span><small data-timer-status>${seconds>0?'En marcha':'Listo para iniciar'}</small></div><div class="timer-helpers"><button class="btn btn-outline btn-mini" data-action="timer-minus">−15 s</button><button class="btn btn-primary btn-mini" data-action="timer-toggle">${icon(seconds>0?'pause':'play',16)} ${seconds>0?'Pausar':'Iniciar'}</button><button class="btn btn-outline btn-mini" data-action="timer-plus">+30 s</button></div><p class="timer-disclaimer">Temporizador de referencia. Descansa lo que necesites.</p></div><div class="rail-note">${icon('info',17)}<p>Registra únicamente series realizadas. Puedes modificar los valores antes de marcarlas como completadas.</p></div>${planned?`<div class="rail-plan"><span class="eyebrow">PLAN ORIGINAL</span><strong>${escapeHtml(planned.title)}</strong><span>${planned.minutes} min estimados</span></div>`:''}</aside></div>`;
}
function timeDisplay(secs){return `${String(Math.floor(secs/60)).padStart(2,'0')}:${String(secs%60).padStart(2,'0')}`}
function exerciseCard(e,index){
 const ex=findExercise(e.exerciseId),type=ex?.type||'strength';
 const done=e.sets.filter(set=>set.done).length;
 const fieldHead=type==='strength'?'<span>REP.</span><span>CARGA (KG)</span><span>RPE</span>':type==='cardio'?'<span>TIEMPO (MIN)</span><span>DISTANCIA (KM)</span><span>RPE</span>':'<span>TIEMPO (MIN)</span><span>RPE</span><span></span>';
 return `<article class="exercise-card"><div class="exercise-card-title"><span class="exercise-number">${String(index+1).padStart(2,'0')}</span><div><h3>${escapeHtml(ex?.name||'Ejercicio no disponible')}</h3><span>${escapeHtml(ex?.group||'Otro')} · ${escapeHtml(ex?.gear||'Personalizado')}</span></div><div class="exercise-done">${done}/${e.sets.length}</div></div><div class="exercise-hint">${escapeHtml(ex?.hint||'') }</div><div class="sets-head"><span>SERIE</span>${fieldHead}<span>HECHA</span></div><div class="sets-body">${e.sets.map((set,i)=>`<div class="set-row ${set.done?'set-complete':''}"><span class="set-index">${i+1}</span>${type==='strength'?`${setInput(e,set,'reps','Reps',1)}${setInput(e,set,'load','kg',0.5)}${setInput(e,set,'rpe','RPE',0.5)}`:type==='cardio'?`${setInput(e,set,'durationMin','min',1)}${setInput(e,set,'distanceKm','km',0.1)}${setInput(e,set,'rpe','RPE',0.5)}`:`${setInput(e,set,'durationMin','min',1)}${setInput(e,set,'rpe','RPE',0.5)}<span class="set-spacer"></span>`}<button class="set-check ${set.done?'is-done':''}" data-action="toggle-set" data-session="${escapeHtml(getCurrentSessionId())}" data-exercise="${e.exerciseId}" data-set="${set.id}" aria-label="${set.done?'Desmarcar':'Completar'} serie ${i+1}">${icon('check',18)}</button></div>`).join('')}</div><div class="exercise-footer"><button class="text-action" data-action="add-set" data-exercise="${e.exerciseId}">${icon('plus',15)} Añadir serie</button><button class="text-action text-action-muted" data-action="remove-set" data-exercise="${e.exerciseId}" ${e.sets.length<=1?'disabled':''}>${icon('minus',15)} Quitar última</button></div></article>`;
}
function getCurrentSessionId(){return currentSession()?.id||''}
function setInput(e,set,field,placeholder,step){const v=set[field]??'';return `<input class="set-input" type="number" inputmode="decimal" min="0" max="100000" step="${step}" aria-label="${placeholder}" data-field="${field}" data-exercise="${e.exerciseId}" data-set="${set.id}" value="${escapeHtml(v)}" placeholder="–" />`}

function progressPage(){const monday=weekStart(),s=statsFor(state.sessions,state.plans,monday),completed=state.sessions.filter(x=>x.status==='completed').sort((a,b)=>(b.finishedAt||'').localeCompare(a.finishedAt||'')),allVolume=completed.reduce((a,x)=>a+totalVolume(x),0),allCardio=completed.reduce((a,x)=>a+cardioTotals(x).mins,0),records=recordsFor(state.sessions);
 return `${pageHead('INTELIGENCIA DEPORTIVA','Tu progreso','Cada dato viene de tus entrenamientos realizados, nunca de estimaciones inventadas.')}
<div class="metric-grid">${smallMetric('check','Sesiones totales',`${completed.length}`,'Histórico completo')}${smallMetric('dumbbell','Volumen registrado',`${fmt(allVolume)}<span class="metric-unit"> kg</span>`,'Series con carga')}${smallMetric('activity','Cardio registrado',`${fmt(allCardio)}<span class="metric-unit"> min</span>`,'Entrenamientos cardio')}${smallMetric('award','Récords de carga',`${records.length}`,'Ejercicios con marca')}</div>
<div class="analytics-grid"><section class="panel analytics-panel">${sectionHead('Constancia','Entrenamientos completados por semana')}${barChart(historyByWeek(completed,monday,8),'count')}</section><section class="panel analytics-panel">${sectionHead('Volumen','Kg acumulados por semana, cuando se registra carga')}${barChart(historyByWeek(completed,monday,8),'volume')}</section></div>
<div class="analytics-grid progress-lower"><section class="panel"><div class="panel-header">${sectionHead('Historial de sesiones','Tus entrenamientos, ordenados por fecha')}</div><div class="history-list">${completed.length?completed.slice(0,20).map(item=>`<div class="history-item"><div class="history-icon">${icon(item.type==='Fuerza'?'dumbbell':item.type==='Resistencia'?'activity':'wind',19)}</div><div><strong>${escapeHtml(item.title)}</strong><span>${dateLabel(item.date)} · ${countDone(item)} registros · ${durationMinutes(item)} min</span></div><span class="history-done">${icon('check',16)}</span></div>`).join(''):'<div class="empty-sm">Cuando completes una sesión, aparecerá aquí automáticamente.</div>'}</div></section><section class="panel"><div class="panel-header">${sectionHead('Marcas registradas','Máxima carga utilizada por ejercicio')}</div><div class="records-list">${records.length?records.slice(0,10).map(r=>`<div class="record-item"><span>${escapeHtml(findExercise(r.exerciseId)?.name||'Ejercicio')}</span><strong>${fmt(r.load)} kg</strong></div>`).join(''):'<div class="empty-sm">Los récords aparecerán si registras cargas en ejercicios de fuerza.</div>'}</div><div class="insight-line">${icon('info',16)} No es una estimación de fuerza máxima ni un indicador de salud.</div></section></div>
<div class="tip-panel">${icon('heart',19)} <div><strong>El progreso no es lineal.</strong><p>Las pausas, los días de recuperación y los cambios de rutina también forman parte de un proceso saludable.</p></div></div>`;
}

function settingsPage(){const p=state.profile;return `${pageHead('TU ESPACIO','Preferencias','Control total sobre tu perfil y tus datos.')}
<div class="settings-grid"><section class="panel settings-panel">${sectionHead('Perfil deportivo','Puedes modificar tu configuración en cualquier momento.')}
<form data-form="settings" class="form-stack"><label class="field-label" for="edit-name">Nombre</label><input class="text-input" id="edit-name" name="name" maxlength="48" value="${escapeHtml(p?.name||'')}" placeholder="Atleta"/><label class="field-label" for="edit-goal">Objetivo principal</label><select class="select-input" id="edit-goal" name="goal">${['Rendimiento híbrido','Fuerza','Resistencia','Movilidad'].map(g=>`<option value="${g}" ${p?.goal===g?'selected':''}>${g}</option>`).join('')}</select><div class="field-label">Días planificados</div><div class="number-choices">${[3,4,5,6].map(n=>`<label class="number-choice"><input type="radio" name="days" value="${n}" ${Number(p?.days)===n?'checked':''}/><span>${n}</span></label>`).join('')}</div><div class="field-label">Equipamiento</div><div class="gear-choices">${GEAR.map(g=>`<label class="check-chip"><input type="checkbox" name="gear" value="${g.id}" ${(p?.gear||[]).includes(g.id)?'checked':''}/><span>${g.name}</span></label>`).join('')}</div><button class="btn btn-primary" type="submit">${icon('check',17)} Guardar preferencias</button></form><p class="form-help">Cambiar preferencias no modifica sesiones ya registradas ni reescribe el plan existente.</p></section>
<section class="panel settings-panel">${sectionHead('Privacidad y seguridad','Tus datos permanecen en este dispositivo.')}
<div class="settings-feature"><span>${icon('shield',19)}</span><div><strong>Sin cuenta</strong><p>No necesitas registrarte ni compartir tu historial con un servidor.</p></div></div><div class="settings-feature"><span>${icon('download',19)}</span><div><strong>Exportación de respaldo</strong><p>Guarda un archivo JSON con perfil, planes y sesiones.</p></div></div><div class="action-stack">${button('export',`${icon('download',18)} Exportar mis datos`,'btn-outline btn-block')}<label class="btn btn-outline btn-block import-label">${icon('upload',18)} Importar copia de seguridad<input type="file" id="import-file" accept=".json,application/json" hidden/></label></div><hr class="settings-rule"/><div class="danger-area"><strong>Zona de eliminación</strong><p>Eliminar los datos locales es irreversible si no conservas una copia.</p>${button('reset',`${icon('trash',17)} Eliminar todos los datos`,'btn-danger')}</div></section></div>`}

function editPlanModal(){const date=state.modal.date,existing=getPlan(date),selected=new Set(existing?.exerciseIds||[]);const selectExercises=availableExercises();return `<div class="modal-backdrop" data-action="close-modal"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><div class="eyebrow">EDITAR PLAN</div><h2 id="modal-title">${cap(new Intl.DateTimeFormat('es-ES',{weekday:'long',day:'numeric',month:'long'}).format(parseLocalDate(date)))}</h2></div><button class="icon-button" data-action="close-modal" aria-label="Cerrar">${icon('close',22)}</button></div><form data-form="edit-plan" class="modal-form"><input type="hidden" name="date" value="${date}"/><label class="field-label" for="plan-title">Nombre de la sesión</label><input class="text-input" id="plan-title" maxlength="70" name="title" required value="${escapeHtml(existing?.title||'Nueva sesión')}"/><label class="field-label" for="plan-type">Tipo de sesión</label><select class="select-input" id="plan-type" name="type">${[...ACTIVITY_TYPES,'Descanso'].map(type=>`<option ${existing?.type===type?'selected':''} value="${type}">${type}</option>`).join('')}</select><label class="field-label" for="plan-duration">Duración estimada (minutos)</label><input class="text-input" id="plan-duration" name="minutes" type="number" min="0" max="240" value="${existing?.minutes??60}"/><div class="field-label">Ejercicios disponibles <span>Selecciona los que correspondan</span></div><div class="modal-exercises">${selectExercises.map(ex=>`<label class="modal-exercise"><input type="checkbox" name="exercise" value="${ex.id}" ${selected.has(ex.id)?'checked':''}/><span><b>${escapeHtml(ex.name)}</b><small>${escapeHtml(ex.group)} · ${ex.type==='cardio'?'Cardio':ex.type==='mobility'?'Movilidad':'Fuerza'}</small></span></label>`).join('')}</div><div class="modal-actions"><button type="button" class="btn btn-outline" data-action="close-modal">Cancelar</button><button class="btn btn-primary" type="submit">${icon('check',17)} Guardar sesión</button></div></form></section></div>`}

function render({keepScroll=false}={}){const scroll=keepScroll?window.scrollY:0;el.innerHTML=state.profile?appShell(state.page==='home'?dashboard():state.page==='plan'?planPage():state.page==='train'?trainingPage():state.page==='progress'?progressPage():settingsPage()):onboarding();if(state.modal)el.insertAdjacentHTML('beforeend',editPlanModal());document.title=`Entreno OS · ${state.profile?(state.page==='home'?'Inicio':state.page==='plan'?'Plan':state.page==='train'?'Entrenar':state.page==='progress'?'Progreso':'Ajustes'):'Bienvenida'}`;if(keepScroll)requestAnimationFrame(()=>window.scrollTo({top:scroll}));else window.scrollTo({top:0,behavior:'instant'});updateConnectivity()}
function updateConnectivity(){const label=document.getElementById('connectivity-label');if(label)label.textContent=navigator.onLine?'Local · listo':'Sin conexión';}
function navigate(page){state.page=page;state.modal=null;history.replaceState(null,'',`#${page}`);render()}
function eventTarget(action){return action?.closest?.('[data-action]')}

async function run(action,buttonNode){
 const planId=buttonNode.dataset.plan;
 switch(action){
 case 'home': case 'plan': case 'train': case 'progress': case 'settings': return navigate(action);
 case 'resume': return navigate('train');
 case 'prev-week': state.week=addDays(state.week,-7);return render();
 case 'next-week': state.week=addDays(state.week,7);return render();
 case 'edit-plan':state.modal={date:buttonNode.dataset.date};return render({keepScroll:true});
 case 'close-modal':state.modal=null;return render({keepScroll:true});
 case 'create-week':{
   const week=state.week;
   const existing=state.plans.some(p=>p.date>=week&&p.date<addDays(week,7));
   if(existing&&!confirm('¿Regenerar el plan de esta semana? Se reemplazarán los días no registrados.'))return;
   try{await db.replaceWeek(planForWeek(state.profile,week),week);await reload();notice('Plan semanal generado');render({keepScroll:true});}catch(e){notice(e.message)}return;
 }
 case 'start':{
   const plan=state.plans.find(p=>p.id===planId);
   if(!plan){notice('No se encontró el plan');return}
   if(plan.isRest){notice('Este día está reservado para descansar');return}
   const already=getActiveForPlan(plan.id);
   const existingOther=currentSession();
   if(!already&&existingOther){notice('Hay una sesión sin terminar. Continúala antes de iniciar otra.');return navigate('train')}
   if(!already&&completedForPlan(plan.id)){notice('Esta sesión ya está completada');return}
   if(!already){await db.put('sessions',newSession(plan));await reload();}
   return navigate('train');
 }
 case 'toggle-set':{const s=currentSession(),entry=s?.entries.find(e=>e.exerciseId===buttonNode.dataset.exercise),set=entry?.sets.find(x=>x.id===buttonNode.dataset.set);if(!set)return;set.done=!set.done;s.updatedAt=new Date().toISOString();await db.put('sessions',s);return render({keepScroll:true});}
 case 'add-set':{const s=currentSession(),entry=s?.entries.find(e=>e.exerciseId===buttonNode.dataset.exercise);if(!entry)return;entry.sets.push(defaultSet(entry.exerciseId));s.updatedAt=new Date().toISOString();await db.put('sessions',s);return render({keepScroll:true});}
 case 'remove-set':{const s=currentSession(),entry=s?.entries.find(e=>e.exerciseId===buttonNode.dataset.exercise);if(!entry||entry.sets.length<=1)return;if(entry.sets.at(-1).done&&!confirm('La última serie está registrada. ¿Eliminarla?'))return;entry.sets.pop();s.updatedAt=new Date().toISOString();await db.put('sessions',s);return render({keepScroll:true});}
 case 'finish':{const s=currentSession();if(!s)return;if(countDone(s)===0){notice('Marca al menos un registro realizado antes de finalizar.');return}if(!confirm('¿Finalizar esta sesión? Los registros quedarán guardados en tu historial.'))return;s.status='completed';s.restUntil=null;s.finishedAt=new Date().toISOString();s.updatedAt=s.finishedAt;await db.put('sessions',s);await reload();notice('Sesión guardada en tu historial');return navigate('progress')}
 case 'timer-toggle':case 'timer-minus':case 'timer-plus':{const s=currentSession();if(!s)return;const remain=s.restUntil?Math.max(0,Math.ceil((s.restUntil-Date.now())/1000)):0;let secs=remain;if(action==='timer-toggle')secs=remain>0?0:90;if(action==='timer-plus')secs=remain+30;if(action==='timer-minus')secs=Math.max(0,remain-15);s.restUntil=secs?Date.now()+secs*1000:null;await db.put('sessions',s);return render({keepScroll:true});}
 case 'export':{const blob=new Blob([JSON.stringify(await db.backup(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`entreno-os-respaldo-${localDate()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Respaldo exportado');return}
 case 'reset':{clearTimeout(inputSaveHandle);if(!confirm('¿Eliminar todos los datos de Entreno OS de este dispositivo?'))return;if(!confirm('Esta acción no se puede deshacer sin una copia. ¿Confirmas la eliminación?'))return;await db.deleteEverything();state.modal=null;state.page='home';await reload();render();notice('Datos eliminados');return}
 }
}
// Event delegation; all user-entered strings are escaped before rendering.
document.addEventListener('click',async event=>{const target=eventTarget(event.target);if(!target)return;const action=target.dataset.action;if(target.classList.contains('modal-backdrop')&&event.target!==target)return;event.preventDefault();if(state.busy)return;try{state.busy=true;await run(action,target)}catch(e){console.error(e);notice('No se pudo completar la acción: '+e.message)}finally{state.busy=false}});

let inputSaveHandle;
document.addEventListener('input',event=>{
 const input=event.target;
 if(!input.matches?.('[data-field]'))return;
 const s=currentSession(),entry=s?.entries.find(e=>e.exerciseId===input.dataset.exercise),set=entry?.sets.find(x=>x.id===input.dataset.set);
 if(!set)return;
 set[input.dataset.field]=input.value===''?'':clampNonNegative(input.value);
 s.updatedAt=new Date().toISOString();
 clearTimeout(inputSaveHandle);
 inputSaveHandle=setTimeout(()=>db.put('sessions',s).catch(e=>notice('No se guardó el valor: '+e.message)),180);
});
document.addEventListener('change',async event=>{
 const input=event.target;
 if(input.matches('[data-field]')){
  const s=currentSession(),entry=s?.entries.find(e=>e.exerciseId===input.dataset.exercise),set=entry?.sets.find(x=>x.id===input.dataset.set);if(!set)return;
  const v=input.value===''?'':clampNonNegative(input.value);
  set[input.dataset.field]=v;
  s.updatedAt=new Date().toISOString();
  try{await db.put('sessions',s);notice('Registro guardado')}catch{notice('No se guardó el cambio; inténtalo de nuevo')}
 }
 if(input.id==='import-file'&&input.files?.[0]){
  try{
   if(input.files[0].size>12*1024*1024)throw new Error('Archivo demasiado grande (máximo 12 MB).');
   const doc=JSON.parse(await input.files[0].text());
   if(!confirm('La importación reemplazará los datos actuales. ¿Continuar?'))return;
   clearTimeout(inputSaveHandle);await db.importBackup(doc);await reload();state.week=weekStart();state.page='home';render();notice('Respaldo importado correctamente');
  }catch(e){notice('No se pudo importar: '+e.message)}
 }
});

document.addEventListener('submit',async event=>{
 const form=event.target;if(!form.dataset.form)return;event.preventDefault();if(state.busy)return;state.busy=true;
 try{
  const values=new FormData(form);
  if(form.dataset.form==='onboarding'){
   const profile={name:String(values.get('name')||'').trim().slice(0,48),goal:String(values.get('goal')||'Rendimiento híbrido'),days:Number(values.get('days')||6),gear:[...new Set(['corporal',...values.getAll('gear')])],createdAt:new Date().toISOString()};
   await db.setProfile(profile);await db.replaceWeek(planForWeek(profile,weekStart()),weekStart());await reload();state.page='home';render();notice('Tu espacio está listo');
  }else if(form.dataset.form==='settings'){
   const profile={...state.profile,name:String(values.get('name')||'').trim().slice(0,48),goal:String(values.get('goal')||'Rendimiento híbrido'),days:Number(values.get('days')||6),gear:[...new Set(['corporal',...values.getAll('gear')])]};
   await db.setProfile(profile);await reload();render({keepScroll:true});notice('Preferencias actualizadas');
  }else if(form.dataset.form==='edit-plan'){
   const date=String(values.get('date')),old=getPlan(date),type=String(values.get('type')),title=String(values.get('title')||'Nueva sesión').trim().slice(0,70),duration=Math.max(0,Math.min(240,Number(values.get('minutes')||0))),ids=values.getAll('exercise').filter(x=>EXERCISES.some(e=>e.id===x));
   if(!title)throw new Error('Escribe un título válido');
   if(old&&byPlan(old.id).length){notice('Esta sesión tiene registros y no puede editarse.');return}
   const plan={id:old?.id||uuid(),date,title,type,minutes:type==='Descanso'?0:duration,exerciseIds:type==='Descanso'?[]:ids,isRest:type==='Descanso'};
   await db.put('plans',plan);state.modal=null;await reload();render({keepScroll:true});notice('Plan guardado');
  }
 }catch(e){console.error(e);notice('No se guardó: '+e.message)}finally{state.busy=false}
});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&state.modal){state.modal=null;render({keepScroll:true})}});
window.addEventListener('online',updateConnectivity);window.addEventListener('offline',updateConnectivity);
setInterval(()=>{const timer=document.querySelector('[data-timer-value]');if(!timer)return;const s=currentSession();const secs=s?.restUntil?Math.max(0,Math.ceil((s.restUntil-Date.now())/1000)):0;timer.textContent=timeDisplay(secs);const status=document.querySelector('[data-timer-status]');if(status)status.textContent=secs?'En marcha':'Listo para iniciar';},1000);
async function boot(){try{await reload();if(state.profile){const fragment=location.hash.slice(1);state.page=['home','plan','train','progress','settings'].includes(fragment)?fragment:'home';}render();if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./sw.js',{scope:'./'}).catch(console.warn)}catch(error){console.error(error);el.innerHTML=`<div class="fatal"><h1>No se pudo abrir Entreno OS</h1><p>${escapeHtml(error.message)}</p><p>Revisa los permisos de almacenamiento del navegador y recarga la página.</p></div>`}}
boot();
