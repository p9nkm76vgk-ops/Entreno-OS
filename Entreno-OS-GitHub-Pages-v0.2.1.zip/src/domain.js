import { EXERCISES, ROUTINE_TEMPLATES } from './data.js';

export const localDate = (date=new Date()) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
export function parseLocalDate(str){ const [y,m,d]=str.split('-').map(Number); return new Date(y,m-1,d,12); }
export function addDays(dateString,amount){const d=parseLocalDate(dateString);d.setDate(d.getDate()+amount);return localDate(d);}
export function weekStart(dateString=localDate()) {const day=parseLocalDate(dateString).getDay();return addDays(dateString,-((day+6)%7));}
export const shortDay = dateString => new Intl.DateTimeFormat('es-ES',{weekday:'short'}).format(parseLocalDate(dateString)).replace('.','');
export const dateLabel = dateString => new Intl.DateTimeFormat('es-ES',{day:'numeric',month:'short'}).format(parseLocalDate(dateString));
export const fullDateLabel = dateString => new Intl.DateTimeFormat('es-ES',{day:'numeric',month:'long',year:'numeric'}).format(parseLocalDate(dateString));
export const uuid = () => globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
export const findExercise = id => EXERCISES.find(ex=>ex.id===id);

export function planForWeek(profile,monday){
 const days = Math.max(3,Math.min(6,Number(profile.days)||4));
 const indices = ({3:[0,2,4],4:[0,1,2,4],5:[0,1,2,3,4],6:[0,1,2,3,4,5]})[days];
 const available = new Set(['corporal',...(profile.gear||[])]);
 const out = [];
 for(let index=0;index<7;index++){
   const date=addDays(monday,index);
   const scheduled=indices.includes(index);
   if(!scheduled){out.push({id:uuid(),date,title:'Descanso y recuperación',type:'Descanso',minutes:0,exerciseIds:[],isRest:true});continue;}
   const templateIndex=indices.indexOf(index);
   const template=ROUTINE_TEMPLATES[days===3?[0,2,4][templateIndex]:days===4?[0,1,2,4][templateIndex]:days===5?[0,1,2,3,4][templateIndex]:templateIndex];
   const selected=template.ids.map(group=>group.split('|').map(findExercise).find(ex=>ex && available.has(ex.gear))?.id).filter(Boolean);
   out.push({id:uuid(),date,title:template.title,type:template.type,minutes:template.minutes,exerciseIds:[...new Set(selected)],isRest:false});
 }
 return out;
}

export function newSession(plan){
 return {id:uuid(),planId:plan.id,date:plan.date,title:plan.title,type:plan.type,startedAt:new Date().toISOString(),updatedAt:new Date().toISOString(),finishedAt:null,status:'active',restUntil:null,entries:(plan.exerciseIds||[]).map(id=>({exerciseId:id,sets:Array.from({length:findExercise(id)?.type==='strength'?3:1},()=>defaultSet(id))}))};
}
export function defaultSet(exerciseId){const ex=findExercise(exerciseId);return {id:uuid(),done:false,reps:ex?.type==='strength'?'8':'',load:'',rpe:'',durationMin:ex?.type==='cardio'?'15':ex?.type==='mobility'?'5':'',distanceKm:''};}
export const countDone = session => (session.entries||[]).reduce((acc,e)=>acc+(e.sets||[]).filter(s=>s.done).length,0);
export function totalVolume(session){return (session.entries||[]).reduce((acc,e)=>{if(findExercise(e.exerciseId)?.type!=='strength')return acc;return acc+(e.sets||[]).reduce((s,v)=>s+(v.done?(Number(v.reps)||0)*(Number(v.load)||0):0),0)},0);}
export function cardioTotals(session){let mins=0,km=0;for(const e of session.entries||[]){if(findExercise(e.exerciseId)?.type!=='cardio')continue;for(const s of e.sets||[]){if(s.done){mins+=Number(s.durationMin)||0;km+=Number(s.distanceKm)||0;}}}return {mins,km};}
export function durationMinutes(session){if(!session?.startedAt)return 0;const end=session.finishedAt?new Date(session.finishedAt).getTime():Date.now();return Math.max(0,Math.round((end-new Date(session.startedAt).getTime())/60000));}
export function statsFor(sessions,plans,week){
 const completed=sessions.filter(s=>s.status==='completed');
 const weekEnd=addDays(week,7);
 const inWeek=completed.filter(s=>s.date>=week&&s.date<weekEnd);
 const planned=plans.filter(p=>p.date>=week&&p.date<weekEnd&&!p.isRest).length;
 const volume=inWeek.reduce((a,s)=>a+totalVolume(s),0);
 const cardio=inWeek.reduce((a,s)=>{const c=cardioTotals(s);return {mins:a.mins+c.mins,km:a.km+c.km}}, {mins:0,km:0});
 const minutes=inWeek.reduce((a,s)=>a+durationMinutes(s),0);
 return {completed:inWeek.length,planned,consistency:planned?Math.min(100,Math.round(inWeek.length/planned*100)):0,volume,cardio,minutes};
}
export function historyByWeek(sessions,week,num=6){
 return Array.from({length:num},(_,i)=>{
   const start=addDays(week,(i-(num-1))*7),end=addDays(start,7);
   const done=sessions.filter(s=>s.status==='completed'&&s.date>=start&&s.date<end);
   return {start,count:done.length,volume:done.reduce((a,s)=>a+totalVolume(s),0),label:`${parseLocalDate(start).getDate()}/${parseLocalDate(start).getMonth()+1}`};
 });
}
export function recordsFor(sessions){
 const records=new Map();
 for(const s of sessions.filter(s=>s.status==='completed'))for(const e of s.entries||[]){
   if(findExercise(e.exerciseId)?.type!=='strength')continue;
   for(const set of e.sets||[]){
     if(!set.done)continue;const load=Number(set.load)||0;
     if(load>0&&load>(records.get(e.exerciseId)?.load||0))records.set(e.exerciseId,{exerciseId:e.exerciseId,load,date:s.date});
   }
 }
 return [...records.values()].sort((a,b)=>b.load-a.load);
}
export function clampNonNegative(value){const n=Number(value);return Number.isFinite(n)?Math.max(0,Math.min(n,100000)):0;}
