/** Capa de persistencia: una sola base de datos, cuatro colecciones. */
const DB_NAME='entreno-os-v1';
const VERSION=1;
let opening;
function connect(){
 if(opening)return opening;
 opening=new Promise((resolve,reject)=>{
   const req=indexedDB.open(DB_NAME,VERSION);
   req.onupgradeneeded=()=>{
     const db=req.result;
     if(!db.objectStoreNames.contains('kv'))db.createObjectStore('kv',{keyPath:'key'});
     if(!db.objectStoreNames.contains('plans')){const p=db.createObjectStore('plans',{keyPath:'id'});p.createIndex('date','date');}
     if(!db.objectStoreNames.contains('sessions')){const s=db.createObjectStore('sessions',{keyPath:'id'});s.createIndex('date','date');s.createIndex('status','status');}
   };
   req.onsuccess=()=>resolve(req.result);
   req.onerror=()=>{opening=undefined;reject(req.error)};
   req.onblocked=()=>{opening=undefined;reject(new Error('Cierra otras pestañas de Entreno OS e inténtalo de nuevo.'))};
 });
 return opening;
}
function transaction(store,mode,execute){return connect().then(db=>new Promise((resolve,reject)=>{
 const tx=db.transaction(store,mode),object=tx.objectStore(store);let result;
 const req=execute(object);if(req){req.onsuccess=()=>{result=req.result};req.onerror=()=>reject(req.error)}
 tx.oncomplete=()=>resolve(result);
 tx.onerror=()=>reject(tx.error);
 tx.onabort=()=>reject(tx.error||new Error('Operación cancelada'));
}));}
export const db={
 get:(store,key)=>transaction(store,'readonly',o=>o.get(key)),
 all:store=>transaction(store,'readonly',o=>o.getAll()),
 put:(store,value)=>transaction(store,'readwrite',o=>o.put(structuredClone(value))),
 delete:(store,key)=>transaction(store,'readwrite',o=>o.delete(key)),
 clear:store=>transaction(store,'readwrite',o=>o.clear()),
 async getProfile(){return (await this.get('kv','profile'))?.value||null},
 async setProfile(value){return this.put('kv',{key:'profile',value})},
 async replaceWeek(plans,monday){
  const d=new Date(`${monday}T12:00:00`);d.setDate(d.getDate()+7);
  const next=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const existing=(await this.all('plans')).filter(p=>p.date>=monday&&p.date<next);
  const sessions=await this.all('sessions');
  if(existing.some(p=>sessions.some(s=>s.planId===p.id)))throw new Error('Esta semana contiene entrenamientos registrados. Edita los días individualmente.');
  const connection=await connect();
  await new Promise((resolve,reject)=>{
   const tx=connection.transaction('plans','readwrite'),store=tx.objectStore('plans');
   for(const p of existing)store.delete(p.id);
   for(const p of plans)store.put(structuredClone(p));
   tx.oncomplete=resolve;
   tx.onerror=()=>reject(tx.error);
   tx.onabort=()=>reject(tx.error);
  });
 },
 async backup(){return {format:'entreno-os',version:1,exportedAt:new Date().toISOString(),profile:await this.getProfile(),plans:await this.all('plans'),sessions:await this.all('sessions')}},
 async importBackup(doc){
  if(!doc||doc.format!=='entreno-os'||doc.version!==1||!doc.profile||!Array.isArray(doc.plans)||!Array.isArray(doc.sessions))throw new Error('Copia incompatible o incompleta.');
  if(doc.plans.length>10000||doc.sessions.length>100000)throw new Error('Copia demasiado grande.');
  const validId=id=>typeof id==='string'&&/^[a-zA-Z0-9_-]{1,90}$/.test(id);
  const validDate=date=>{if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date))return false;const d=new Date(date+'T12:00:00');return !Number.isNaN(d.getTime())&&`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`===date};
  const validText=text=>typeof text==='string'&&text.length<=300;
  const validType=type=>['Fuerza','Resistencia','Movilidad','Híbrido','Descanso'].includes(type);
  const validMeasure=value=>value===''||value===undefined||(Number.isFinite(Number(value))&&Number(value)>=0&&Number(value)<=100000);
  if(typeof doc.profile!=='object'||Array.isArray(doc.profile)||!validText(doc.profile.name||'')||!Array.isArray(doc.profile.gear)||doc.profile.gear.length>20)throw new Error('Perfil inválido en la copia.');
  for(const p of doc.plans){if(!validId(p.id)||!validDate(p.date)||!validText(p.title)||!validType(p.type)||typeof p.isRest!=='boolean'||!validMeasure(p.minutes)||!Array.isArray(p.exerciseIds)||p.exerciseIds.length>100||p.exerciseIds.some(id=>!validId(id)))throw new Error('Plan inválido en la copia.');}
  for(const s of doc.sessions){
    if(!validId(s.id)||!validId(s.planId)||!validDate(s.date)||!validText(s.title)||!validType(s.type)||!Array.isArray(s.entries)||s.entries.length>100||!['active','completed'].includes(s.status)||Number.isNaN(Date.parse(s.startedAt)))throw new Error('Sesión inválida en la copia.');
    for(const e of s.entries){if(!validId(e.exerciseId)||!Array.isArray(e.sets)||e.sets.length>100||e.sets.some(x=>!validId(x.id)||typeof x.done!=='boolean'||['reps','load','rpe','durationMin','distanceKm'].some(f=>!validMeasure(x[f]))))throw new Error('Registro de ejercicio inválido en la copia.');}
  }
  const connection=await connect();
  await new Promise((resolve,reject)=>{
    const tx=connection.transaction(['kv','plans','sessions'],'readwrite');
    for(const name of ['kv','plans','sessions'])tx.objectStore(name).clear();
    tx.objectStore('kv').put({key:'profile',value:doc.profile});
    for(const p of doc.plans)tx.objectStore('plans').put(p);
    for(const s of doc.sessions)tx.objectStore('sessions').put(s);
    tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
  });
 },
 async deleteEverything(){const connection=await connect();await new Promise((resolve,reject)=>{const tx=connection.transaction(['kv','plans','sessions'],'readwrite');for(const n of ['kv','plans','sessions'])tx.objectStore(n).clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
};
