/** Catálogo inicial. Los valores son ejemplos editables, no prescripciones personales. */
export const EXERCISES = [
  {id:'pushup', name:'Flexiones', type:'strength', gear:'corporal', group:'Tren superior', hint:'Movimiento controlado y rango cómodo.'},
  {id:'row-dumbbell', name:'Remo con mancuerna', type:'strength', gear:'mancuernas', group:'Espalda', hint:'Controla el movimiento y evita los impulsos.'},
  {id:'row-band', name:'Remo con banda', type:'strength', gear:'bandas', group:'Espalda', hint:'Mantén un movimiento cómodo y estable.'},
  {id:'squat', name:'Sentadilla al aire', type:'strength', gear:'corporal', group:'Tren inferior', hint:'Adapta la profundidad al rango cómodo.'},
  {id:'split-squat', name:'Zancada estática', type:'strength', gear:'corporal', group:'Tren inferior', hint:'Prioriza el equilibrio y el control.'},
  {id:'bridge', name:'Puente de glúteos', type:'strength', gear:'corporal', group:'Tren inferior', hint:'Realiza repeticiones sin molestias.'},
  {id:'plank', name:'Plancha', type:'mobility', gear:'corporal', group:'Core', hint:'Respira con normalidad; reduce la duración si lo necesitas.'},
  {id:'press-dumbbell', name:'Press de hombros con mancuernas', type:'strength', gear:'mancuernas', group:'Hombros', hint:'Emplea una carga que puedas controlar.'},
  {id:'curl-dumbbell', name:'Curl con mancuernas', type:'strength', gear:'mancuernas', group:'Brazos', hint:'Prioriza la técnica frente a la carga.'},
  {id:'lateral-band', name:'Aperturas con banda', type:'strength', gear:'bandas', group:'Hombros', hint:'Mantén una tensión cómoda.'},
  {id:'calf', name:'Elevaciones de talones', type:'strength', gear:'corporal', group:'Tren inferior', hint:'Apóyate si necesitas estabilidad.'},
  {id:'bird-dog', name:'Bird dog', type:'mobility', gear:'corporal', group:'Core', hint:'Alterna lados de forma controlada.'},
  {id:'hips', name:'Movilidad de cadera', type:'mobility', gear:'corporal', group:'Movilidad', hint:'Explora el rango de movimiento sin forzarlo.'},
  {id:'shoulders', name:'Movilidad de hombros', type:'mobility', gear:'corporal', group:'Movilidad', hint:'Evita posiciones dolorosas.'},
  {id:'walk', name:'Caminata a ritmo cómodo', type:'cardio', gear:'corporal', group:'Resistencia', hint:'Ritmo conversacional, adaptable.'},
  {id:'bike', name:'Bicicleta estática', type:'cardio', gear:'bicicleta', group:'Resistencia', hint:'Ajusta el esfuerzo a tu situación.'},
  {id:'step', name:'Subidas a escalón bajo', type:'cardio', gear:'corporal', group:'Resistencia', hint:'Utiliza una superficie estable y segura.'},
  {id:'stretch', name:'Estiramientos suaves', type:'mobility', gear:'corporal', group:'Recuperación', hint:'Sin rebotes ni dolor.'}
];
export const GEAR = [
 {id:'corporal',name:'Peso corporal'}, {id:'mancuernas',name:'Mancuernas'}, {id:'bandas',name:'Bandas elásticas'},
 {id:'esterilla',name:'Esterilla'}, {id:'banco',name:'Banco'}, {id:'bicicleta',name:'Bicicleta estática'}
];
export const ACTIVITY_TYPES = ['Fuerza','Resistencia','Movilidad','Híbrido'];
export const DAYS = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];
export const ROUTINE_TEMPLATES = [
 {title:'Fuerza · Tren superior',type:'Fuerza',minutes:65,ids:['pushup','row-dumbbell|row-band|bird-dog','press-dumbbell|lateral-band|shoulders','plank']},
 {title:'Resistencia · Base',type:'Resistencia',minutes:50,ids:['bike|walk','hips','stretch']},
 {title:'Fuerza · Tren inferior',type:'Fuerza',minutes:65,ids:['squat','split-squat','bridge','calf']},
 {title:'Movilidad y recuperación',type:'Movilidad',minutes:35,ids:['hips','shoulders','bird-dog','stretch']},
 {title:'Fuerza · General',type:'Fuerza',minutes:65,ids:['pushup','squat','row-dumbbell|row-band|bird-dog','bridge']},
 {title:'Resistencia · Suave',type:'Resistencia',minutes:45,ids:['walk','shoulders','stretch']}
];
