# Entreno OS — Decisiones definitivas

## Distribución y autonomía

- El software es una web PWA estática: no necesita empresa de hosting específica ni un servidor de aplicación dinámico.
- El usuario elige dónde alojar los archivos estáticos: GitHub Pages inicialmente, servidor propio si desea autonomía de alojamiento.
- El alojamiento de archivos accesibles mediante HTTPS sigue siendo necesario para la instalación inicial habitual en iPhone; el funcionamiento offline depende de los recursos almacenados y no elimina la necesidad de copias de seguridad.
- La aplicación guarda los registros en IndexedDB del dispositivo, sin enviar el historial deportivo a un backend.

## Exclusión permanente del chatbot

- No se desarrollará chatbot, asistente conversacional ni interfaz de mensajes.
- No se integrarán modelos de lenguaje ni APIs de asistentes generativos.
- Si se amplían los cálculos de planificación o recuperación, se emplearán métodos deterministas y transparentes revisables por el usuario.

## Producto inicial

- Dashboard centrado en la sesión del día.
- Planificador semanal editable.
- Ejecución y registro de ejercicios.
- Historial y gráficos derivados de datos reales.
- Copia de seguridad local mediante exportación/importación.
