# Entreno OS · v0.2.1 — GitHub Pages

Aplicación web personal de entrenamiento deportivo, con planificación semanal, registro de sesiones y estadísticas de progreso. Diseñada para iPhone; también funciona en navegadores de escritorio.

**No tiene chatbot ni utiliza modelos de lenguaje.** Todos los registros de entrenamiento se almacenan localmente en el navegador mediante IndexedDB. Esta aplicación no dispone de backend ni de cuentas de usuario.

## Publicar en GitHub Pages

Consulta [PUBLICAR.md](./PUBLICAR.md). El repositorio incorpora un flujo GitHub Actions (`.github/workflows/pages.yml`) que verifica, compila y publica la web automáticamente después de cada cambio en `main`, una vez habilitado GitHub Pages.

## Ejecutar y validar

Necesitas Node.js 20 o posterior (no se instalan dependencias):

```bash
npm test
npm run build
npm run dev
```

`npm run build` prepara el sitio en `dist/`. En desarrollo, `npm run dev` sirve la app en `http://localhost:4173`.

## Funcionalidades v0.2.1

- Inicio con sesión del día y agenda.
- Planificador de rutinas semanales editable.
- Registro de series, cargas, repeticiones y actividades cardiovasculares con temporizador.
- Historial, gráficos y récords registrados.
- Copias de seguridad JSON exportables e importables.
- PWA con caché para uso offline después de la primera visita.

## Privacidad y limitaciones

El código publicado en el repositorio público será visible para cualquiera, pero **los datos de entrenamiento se quedan en el dispositivo**. No subas al repositorio exportaciones del historial deportivo ni datos personales. El almacenamiento local puede ser eliminado por el navegador: exporta copias periódicamente desde Ajustes. No se ofrecen diagnósticos médicos, predicciones clínicas ni prescripción individualizada.

La versión actual es un MVP. Está pendiente una validación específica con Safari de iPhone y una nueva auditoría interactiva para priorizar mejoras, que realizaremos después de publicar.
