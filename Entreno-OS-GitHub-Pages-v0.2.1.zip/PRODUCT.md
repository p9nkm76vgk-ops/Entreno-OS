# Entreno OS — Especificación y estado de entrega

**Objetivo:** aplicación personal de entrenamiento híbrido que permita planificar, registrar y analizar las actividades desde un iPhone, con una estética cinematográfica oscura. Acceso inicialmente sin cuenta y sin costes recurrentes obligatorios.

## MVP aprobado

| Módulo | Estado | Funciones |
|---|---|---|
| Configuración inicial | Implementado | Objetivo, días semanales, material y nombre opcional |
| Planificador | Implementado | Semana, edición por día, tipos, biblioteca mínima, generar semana |
| Entrenamiento | Implementado | Registro de fuerza, cardio y movilidad, series, temporizador, recuperación de sesión activa |
| Progreso | Implementado | Métricas basadas en sesiones, gráficas semanales, récords registrados, historial |
| Persistencia | Implementado | IndexedDB, importación/exportación, eliminación de registros |
| Distribución | Implementado | App estática, manifest, iconos y service worker |
| QA | Parcial | Pruebas de dominio automatizadas y comprobación visual con navegador simulado |

## Criterios de aceptación del MVP

- [x] Primera configuración crea un plan semanal editable.
- [x] Se puede entrar directamente al entrenamiento de hoy.
- [x] Los registros editados se persisten en la capa de datos.
- [x] Las sesiones completadas alimentan estadísticas reales.
- [x] Un temporizador recupera tiempo restante desde un timestamp guardado.
- [x] Es posible exportar e importar una copia.
- [x] La estructura es responsive y presenta navegación móvil y escritorio.
- [ ] Validar físicamente en Safari de iPhone (sin dispositivo real en este entorno).
- [ ] Auditoría formal de accesibilidad WCAG 2.2 AA.
- [ ] Prueba de continuidad IndexedDB + Service Worker en múltiples dispositivos reales.
- [ ] Pruebas de integración automáticas usando navegador y almacenamiento reales.

## Definiciones deportivas

- **Sesión programada:** plan para una fecha, mutable mientras no existan registros asociados.
- **Sesión realizada:** historial inmutable respecto al plan original, con sets editados durante la sesión.
- **Volumen de fuerza:** sumatorio de (repeticiones × carga externa registrada) sobre las series confirmadas.
- **Minutos cardiovasculares:** tiempo de registros confirmados de ejercicios categorizados como cardio.
- **Constancia semanal:** sesiones completadas sobre sesiones planificadas no clasificadas como descanso. No pretende medir adherencia clínica.
- **Récord de carga:** carga externa máxima registrada para un ejercicio de fuerza. No equivale a una repetición máxima estimada.

## Fuera del MVP

- Chatbot y asistentes conversacionales: **excluidos permanentemente** del proyecto.
- Modelos de lenguaje y servicios generativos: **excluidos permanentemente**.
- Ajustes automáticos complejos y algoritmos de recuperación avanzada: fuera del MVP, posibles únicamente mediante reglas transparentes y supervisables.
- Wearables y medición automática de constantes fisiológicas.
- Notificaciones push con servidor, sincronización, cuenta de Apple o Google.
- Coaching clínico o recomendaciones nutricionales restrictivas.

## Decisiones técnicas

MVP estático en JavaScript ES Modules, base IndexedDB, CSS diseñado específicamente y SVG propio. Almacenamiento local con copia exportable y política clara de privacidad.

Para una siguiente fase comercial se evaluará React + TypeScript, validación más exhaustiva, repositorios por dominio, backend, PWA testing y experiencia multidispositivo.

## Decisiones de producto consolidadas (noviembre de 2026)

1. La aplicación es una PWA que puede alojarse mediante cualquier servidor HTTPS compatible con archivos estáticos. No depende de Vercel, Netlify ni Render.
2. Se prioriza GitHub Pages por sencillez y coste, sin confundirlo con infraestructura totalmente autónoma. Para independencia completa de un proveedor de hosting sería necesario un servidor propio.
3. No habrá chatbot, asistente conversacional ni integración con modelos de lenguaje ahora o en el futuro.
4. Las futuras recomendaciones deportivas, si se implementan, se basarán exclusivamente en reglas deterministas, comprensibles, configurables y supervisables.
5. La persistencia local y las copias de seguridad seguirán siendo capacidades centrales.
