import test from 'node:test';
import assert from 'node:assert/strict';
import { EXERCISES } from '../src/data.js';
import { localDate, parseLocalDate, addDays, weekStart, planForWeek, newSession, totalVolume, cardioTotals, countDone, statsFor, recordsFor, historyByWeek, clampNonNegative } from '../src/domain.js';

const monday='2026-11-16';
const profile={name:'Deportista',goal:'Rendimiento híbrido',gear:['corporal','mancuernas'],days:6};

test('manejo de fechas de la semana y cruce de año',()=>{
 assert.equal(weekStart('2026-11-22'),monday);
 assert.equal(weekStart('2027-01-01'),'2026-12-28');
 assert.equal(addDays('2026-12-31',1),'2027-01-01');
 assert.equal(localDate(parseLocalDate('2026-11-16')),monday);
});

test('seis días planificados incluyen un día de descanso',()=>{
 const week=planForWeek(profile,monday);
 assert.equal(week.length,7);
 assert.equal(week.filter(p=>!p.isRest).length,6);
 assert.equal(week[6].isRest,true);
 assert.equal(week[6].exerciseIds.length,0);
 assert.equal(new Set(week.map(p=>p.date)).size,7);
 assert.ok(week.every(p=>p.date>=monday&&p.date<=addDays(monday,6)));
});

test('la selección del material no propone ejercicios incompatibles',()=>{
 const week=planForWeek({...profile,gear:['corporal'],days:4},monday);
 const ids=week.flatMap(p=>p.exerciseIds);
 assert.equal(week.filter(p=>!p.isRest).length,4);
 assert.ok(ids.length>0);
 assert.ok(ids.every(id=>EXERCISES.find(ex=>ex.id===id)?.gear==='corporal'));
});

test('nueva sesión contiene series editables y estados iniciales vacíos',()=>{
 const plan=planForWeek(profile,monday)[0];
 const s=newSession(plan);
 assert.equal(s.status,'active');
 assert.equal(s.planId,plan.id);
 assert.equal(s.entries.length,plan.exerciseIds.length);
 assert.ok(s.entries.every(e=>e.sets.length===(EXERCISES.find(ex=>ex.id===e.exerciseId)?.type==='strength'?3:1)&&e.sets.every(set=>set.done===false))); 
 assert.equal(countDone(s),0);
});

test('el volumen solo suma series realizadas con carga explícita',()=>{
 const s=newSession(planForWeek(profile,monday)[0]);
 const entry=s.entries.find(e=>EXERCISES.find(x=>x.id===e.exerciseId)?.type==='strength');
 assert.ok(entry);
 entry.sets[0]={...entry.sets[0],done:true,reps:10,load:8};
 entry.sets[1]={...entry.sets[1],done:false,reps:100,load:100};
 entry.sets[2]={...entry.sets[2],done:true,reps:8,load:''};
 assert.equal(totalVolume(s),80);
 assert.equal(countDone(s),2);
});

test('el cardio solo registra minutos y kilómetros de registros confirmados',()=>{
 const plan=planForWeek(profile,monday).find(p=>p.type==='Resistencia');
 const s=newSession(plan);
 const e=s.entries.find(e=>EXERCISES.find(x=>x.id===e.exerciseId)?.type==='cardio');
 assert.ok(e);
 e.sets[0]={...e.sets[0],done:true,durationMin:22,distanceKm:4.5};
 e.sets[1]={...e.sets[1],done:false,durationMin:50,distanceKm:10};
 assert.deepEqual(cardioTotals(s),{mins:22,km:4.5});
});

test('las estadísticas excluyen sesiones activas y otros periodos',()=>{
 const week=planForWeek(profile,monday);
 const s=newSession(week[0]);
 const e=s.entries.find(e=>EXERCISES.find(x=>x.id===e.exerciseId)?.type==='strength');
 e.sets[0].done=true;e.sets[0].reps=10;e.sets[0].load=5;
 const active=structuredClone(s);
 s.status='completed';s.finishedAt=new Date(new Date(s.startedAt).getTime()+60*60000).toISOString();
 const stats=statsFor([s,active],week,monday);
 assert.equal(stats.completed,1);
 assert.equal(stats.planned,6);
 assert.equal(stats.volume,50);
 assert.equal(stats.consistency,17);
 assert.equal(stats.minutes,60);
 assert.equal(historyByWeek([s],monday,2)[1].count,1);
 assert.equal(recordsFor([s,active])[0].load,5);
});

test('valores negativos y no numéricos no pueden generar métricas negativas',()=>{
 assert.equal(clampNonNegative(-20),0);
 assert.equal(clampNonNegative('no válido'),0);
 assert.equal(clampNonNegative(10000000),100000);
 assert.equal(clampNonNegative('5.5'),5.5);
});
