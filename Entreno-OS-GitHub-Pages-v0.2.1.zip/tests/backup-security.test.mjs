import test from 'node:test';
import assert from 'node:assert/strict';
import {db} from '../src/db.js';
const id='test123';
const profile={name:'',gear:['corporal'],days:4,goal:'Rendimiento híbrido'};
const makeDoc=()=>({format:'entreno-os',version:1,profile,plans:[{id,date:'2026-11-16',title:'Fuerza',type:'Fuerza',minutes:50,exerciseIds:['pushup'],isRest:false}],sessions:[]});
test('rechaza tipo de entrenamiento malicioso en copia importada antes de modificar datos',async()=>{
 const doc=makeDoc();doc.plans[0].type='<img src=x onerror=alert(1)>';
 await assert.rejects(db.importBackup(doc),/Plan inválido/);
});
test('rechaza fechas imposibles en la importación',async()=>{
 const doc=makeDoc();doc.plans[0].date='2026-02-31';
 await assert.rejects(db.importBackup(doc),/Plan inválido/);
});
test('rechaza métricas no finitas en la importación',async()=>{
 const doc=makeDoc();doc.sessions=[{id:'session1',planId:id,date:'2026-11-16',title:'Fuerza',type:'Fuerza',status:'completed',startedAt:'2026-11-16T18:00:00Z',entries:[{exerciseId:'pushup',sets:[{id:'set1',done:true,reps:'Infinity',load:1}]}]}];
 await assert.rejects(db.importBackup(doc),/Registro de ejercicio inválido/);
});
