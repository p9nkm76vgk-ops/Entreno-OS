import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve, join } from 'node:path';
const root = resolve(fileURLToPath(new URL('../', import.meta.url)));

test('manifest PWA mantiene rutas relativas para sitios en subcarpetas', async () => {
  const manifest = JSON.parse(await readFile(join(root,'manifest.webmanifest'),'utf8'));
  assert.equal(manifest.display,'standalone');
  assert.equal(manifest.start_url,'./');
  assert.equal(manifest.scope,'./');
  for(const item of manifest.icons){ assert.ok(item.src.startsWith('./')); assert.ok((await stat(join(root,item.src))).isFile()); }
  assert.ok(manifest.icons.some(x=>x.sizes==='192x192'));
  assert.ok(manifest.icons.some(x=>x.sizes==='512x512'));
});

test('service worker precachea recursos existentes y evita dependencias externas', async () => {
  const sw = await readFile(join(root,'sw.js'),'utf8');
  const refs=[...sw.matchAll(/'\.(?:\/[^']*)?'/g)].map(m=>m[0].slice(1,-1));
  for(const ref of refs)await stat(join(root,ref));
  assert.ok(refs.includes('./src/main.js'));
  assert.ok(refs.includes('./index.html'));
  assert.match(sw,/name\.startsWith\(PREFIX\)/);
});

test('flujo GitHub Actions valida y despliega a GitHub Pages', async () => {
  const workflow=await readFile(join(root,'.github/workflows/pages.yml'),'utf8');
  assert.match(workflow,/branches:\s*\[main\]/);
  assert.match(workflow,/npm test/);
  assert.match(workflow,/npm run build/);
  assert.match(workflow,/actions\/upload-pages-artifact@v3/);
  assert.match(workflow,/actions\/deploy-pages@v4/);
  assert.match(workflow,/path:\s*\.\/dist/);
});
