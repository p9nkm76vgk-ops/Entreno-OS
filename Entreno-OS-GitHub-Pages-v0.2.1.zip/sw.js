/* Offline-first shell; update files from network when possible and preserve unrelated caches. */
const CACHE = 'entreno-os-shell-v3';
const PREFIX = 'entreno-os-shell-';
const SHELL = [
  './', './index.html', './styles.css', './src/main.js', './src/db.js',
  './src/domain.js', './src/data.js', './src/icons.js', './manifest.webmanifest',
  './assets/logo.svg', './assets/icon-192.png', './assets/icon-512.png',
  './assets/hero-athlete.webp'
];
self.addEventListener('install', event => event.waitUntil(
  caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())
));
self.addEventListener('activate', event => event.waitUntil(
  caches.keys().then(keys => Promise.all(
    keys.filter(name => name.startsWith(PREFIX) && name !== CACHE).map(name => caches.delete(name))
  )).then(() => self.clients.claim())
));
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(request);
      if (response.ok) { try { await cache.put(request, response.clone()); } catch { /* A full cache must not break the online app. */ } }
      return response;
    } catch {
      return (await cache.match(request)) ||
        (request.mode === 'navigate' ? await cache.match(new URL('./index.html', self.registration.scope)) : undefined) ||
        Response.error();
    }
  })());
});
