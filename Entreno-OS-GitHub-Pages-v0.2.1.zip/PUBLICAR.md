# Publicar Entreno OS en GitHub Pages

## Preparación

- Necesitas un repositorio **público** de GitHub (para usar Pages con GitHub Free) llamado preferiblemente `entreno-os`.
- La rama principal debe ser `main`.
- Subir los archivos del proyecto, incluida la ruta oculta `.github/workflows/pages.yml`.
- No subir copias de seguridad personales, contraseñas ni datos privados.

## Activación

1. Abre tu repositorio en GitHub.
2. En **Settings → Pages → Build and deployment → Source**, selecciona **GitHub Actions**.
3. El flujo `Deploy Entreno OS to GitHub Pages` se ejecuta cuando se suben cambios a `main`. También puede ejecutarse desde la pestaña **Actions → Run workflow**.
4. Comprueba que el flujo finaliza correctamente y abre la URL HTTPS mostrada por GitHub en Settings → Pages.

## Comprobaciones después de publicar

- La web se abre desde Safari en iPhone.
- Las imágenes y los estilos cargan sin 404.
- La configuración inicial crea un perfil y un plan semanal.
- Se guarda una sesión y sigue ahí después de cerrar y reabrir.
- El modo progreso se alimenta de registros, no de cifras simuladas.
- Se puede exportar e importar una copia de seguridad.
- Tras cargar la aplicación online, la PWA abre con conexión desactivada.
- Safari permite añadirla a la pantalla de inicio mediante Compartir → Añadir a pantalla de inicio.

## Observaciones

No necesita Vercel ni Netlify. La web utiliza rutas relativas y funciona como sitio de proyecto, por ejemplo bajo una subruta `/<repositorio>/`. **No existe una URL pública hasta que GitHub confirme el despliegue**. La aplicación no requiere chatbot ni servidores de IA.

GitHub Pages publica archivos públicos. Nunca subas exportaciones del historial personal al repositorio. Las copias de seguridad debes guardarlas en Archivos o en un soporte privado.
