/** Publicación reproducible y sin dependencias: incluye únicamente archivos estáticos necesarios. */
import { cp, mkdir, rm, stat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(fileURLToPath(new URL('../', import.meta.url)));
const out = join(root, 'dist');
const required = ['index.html', 'styles.css', 'src', 'assets', 'manifest.webmanifest', 'sw.js'];
for (const item of required) await stat(join(root, item));
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of required) await cp(join(root, item), join(out, item), { recursive: true });
console.log('Entreno OS: distribución estática lista en dist/');
